package com.as.traini8.Entity;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
@Table(name="center")
public class TrainingCenter {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @NotBlank(message = "CenterName is mandatory")
	    @Size(max = 40, message = "CenterName must be less than 40 characters")
	    private String centerName;

	    @NotBlank(message = "CenterCode is mandatory")
	    @Pattern(regexp = "^[a-zA-Z0-9]{12}$", message = "CenterCode must be exactly 12 alphanumeric characters")
	    private String centerCode;

	    @Embedded
	    private Address address;

	    @NotNull(message = "StudentCapacity is mandatory")
	    private Integer studentCapacity;

	    @ElementCollection
	    private List<String> coursesOffered;

	    @SuppressWarnings("unused")
		private Long createdOn; // Epoch time

	    @Email(message = "Invalid email format")
	    private String contactEmail;

	    @NotBlank(message = "ContactPhone is mandatory")
	    @Pattern(regexp = "^\\+?[0-9]{10,15}$", message = "Invalid phone number format")
	    private String contactPhone;
	    
	    

		public TrainingCenter(Long id,
				@NotBlank(message = "CenterName is mandatory") @Size(max = 40, message = "CenterName must be less than 40 characters") String centerName,
				@NotBlank(message = "CenterCode is mandatory") @Pattern(regexp = "^[a-zA-Z0-9]{12}$", message = "CenterCode must be exactly 12 alphanumeric characters") String centerCode,
				Address address, @NotNull(message = "StudentCapacity is mandatory") Integer studentCapacity,
				List<String> coursesOffered, Long createdOn,
				@Email(message = "Invalid email format") String contactEmail,
				@NotBlank(message = "ContactPhone is mandatory") @Pattern(regexp = "^\\+?[0-9]{10,15}$", message = "Invalid phone number format") String contactPhone) {
			super();
			this.id = id;
			this.centerName = centerName;
			this.centerCode = centerCode;
			this.address = address;
			this.studentCapacity = studentCapacity;
			this.coursesOffered = coursesOffered;
			this.createdOn = createdOn;
			this.contactEmail = contactEmail;
			this.contactPhone = contactPhone;
		}

		public TrainingCenter() {
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getCenterName() {
			return centerName;
		}

		public void setCenterName(String centerName) {
			this.centerName = centerName;
		}

		public String getCenterCode() {
			return centerCode;
		}

		public void setCenterCode(String centerCode) {
			this.centerCode = centerCode;
		}

		public Address getAddress() {
			return address;
		}

		public void setAddress(Address address) {
			this.address = address;
		}

		public Integer getStudentCapacity() {
			return studentCapacity;
		}

		public void setStudentCapacity(Integer studentCapacity) {
			this.studentCapacity = studentCapacity;
		}

		public List<String> getCoursesOffered() {
			return coursesOffered;
		}

		public void setCoursesOffered(List<String> coursesOffered) {
			this.coursesOffered = coursesOffered;
		}

		public Long getCreatedOn() {
			return createdOn;
		}

		public void setCreatedOn(Long createdOn) {
			this.createdOn = createdOn;
		}

		public String getContactEmail() {
			return contactEmail;
		}

		public void setContactEmail(String contactEmail) {
			this.contactEmail = contactEmail;
		}

		public String getContactPhone() {
			return contactPhone;
		}

		public void setContactPhone(String contactPhone) {
			this.contactPhone = contactPhone;
		}
	    
	    
}
