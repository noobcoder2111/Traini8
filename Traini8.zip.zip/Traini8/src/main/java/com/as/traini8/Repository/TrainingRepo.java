package com.as.traini8.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.as.traini8.Entity.TrainingCenter;

public interface TrainingRepo extends JpaRepository<TrainingCenter, Long> {

}
