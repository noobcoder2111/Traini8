package com.as.traini8.Service;

import java.util.List;

import com.as.traini8.Entity.TrainingCenter;

public interface TrainingService  {

	 public TrainingCenter createTrainingCenter(TrainingCenter center);
	 
	 public List<TrainingCenter> getAllTrainingCenters();
	
}
