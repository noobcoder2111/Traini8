package com.as.traini8.Service.Impl;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.as.traini8.Entity.TrainingCenter;
import com.as.traini8.Repository.TrainingRepo;
import com.as.traini8.Service.TrainingService;
import com.as.traini8.exception.InvalidInputException;

@Service
public class TrainingServiceImpl implements TrainingService {

    @Autowired
    private TrainingRepo repository;

    @Override
    public TrainingCenter createTrainingCenter(TrainingCenter center) throws InvalidInputException {
        if (center.getCreatedOn() != null) {
            throw new InvalidInputException("createdOn should not be set by the client.");
        }
        center.setCreatedOn(Instant.now().toEpochMilli());
        return repository.save(center);
    }

    @Override
    public List<TrainingCenter> getAllTrainingCenters() {
        return repository.findAll();
    }
}
